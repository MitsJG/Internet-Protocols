/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package peer2peerclient;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.File;

/**
 *
 * @author Arjun
 */
public class SendThread implements Runnable {
    
    Socket cl_socket;
    DataOutputStream outStrm = null;
    DataInputStream inStrm = null;
    String version = "P2P-CI/1.0";
    String cur_dir = System.getProperty("user.dir");

    
    @Override
    public void run() {
        String readLine;
        String delim = "[ ]+";
        String[] data;
        byte rd;
        String Response;
        String nl = "\n";
        
        try {
            cl_socket.setSoTimeout(1000);
            System.out.println("Sending the file...");
            
            readLine = inStrm.readLine();
            System.out.println(readLine);
            System.out.println(inStrm.readLine());
            System.out.println(inStrm.readLine());
            
            data = readLine.split(delim);
            
            if(!data[0].equals("GET") || !data[1].equals("RFC"))
                outStrm.writeBytes(version + " 400" + " BAD REQUEST" + "\n");
            
            if(!data[3].equals(version))
                outStrm.writeBytes(version + " 505" + " P2P-CI VERSION NOT SUPPORTED" + "\n");
            
            String filename = cur_dir + "\\" + data[2] + ".txt";
            FileInputStream readfile = new FileInputStream(filename);
            
            if(null != readfile)
                outStrm.writeBytes(version + " " + "200 OK" + "\n");
            else
                outStrm.writeBytes(version + " 404 " + "Not Found" + "\n");

            SimpleDateFormat dateFormat = new SimpleDateFormat("EE, dd MMM YYYY HH:mm:ss z");
            Date date = new Date();
            System.out.println(dateFormat.format(date));
            
/*            
            //Path file = FileSystems.getDefault().getPath("", filename);
            //BasicFileAttributes attrs = Files.readAttributes(file, BasicFileAttributes.class);
            
            outStrm.writeBytes(dateFormat.format(date) + nl);//date
            outStrm.writeBytes("OS: " + System.getProperty("os.name") + nl);//OS
            outStrm.writeBytes("Last Modified: " + attrs.lastModifiedTime() + nl);//Last Modified
            outStrm.writeBytes("Content-Length: " + attrs.size() + nl);//Content Length
            outStrm.writeBytes("Content-Type: " + "Text/Text" + nl);//Content Type
*/

            File file = new File(filename);
            
            outStrm.writeBytes(dateFormat.format(date) + nl);//date
            outStrm.writeBytes("OS: " + System.getProperty("os.name") + nl);//OS
            outStrm.writeBytes("Last Modified: " + dateFormat.format(file.lastModified()) + nl);//Last Modified
            outStrm.writeBytes("Content-Length: " + file.length() + nl);//Content Length
            outStrm.writeBytes("Content-Type: " + "Text/Text" + nl);//Content Type
            
            int remBytes = readfile.available();

            while(0 != remBytes)
            {
                rd = (byte)readfile.read();
                remBytes = readfile.available();
                outStrm.writeByte(rd);
            }

            outStrm.writeBytes("\n");
            
            inStrm.close();
            outStrm.close();
            cl_socket.close();
            System.out.println("File was sent succesfully!");
           
        } catch (IOException ex) {
            Logger.getLogger(SendThread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    void socket_assign(Socket cl_socket) throws IOException {
        this.cl_socket = cl_socket;
        this.inStrm = new DataInputStream(cl_socket.getInputStream());
        this.outStrm = new DataOutputStream(cl_socket.getOutputStream());
    }
}

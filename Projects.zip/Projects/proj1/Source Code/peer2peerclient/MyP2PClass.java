package peer2peerclient;

import com.sun.org.apache.bcel.internal.util.ClassPath;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

public class MyP2PClass implements Runnable {

    @Override
    public void run() {
        try {
            System.out.println("Wassup dude!!");
            ServerSocket u_socket = null;
            Socket cl_socket;
            SendThread sendthread;
            
            u_socket = new ServerSocket(upload_port);
            
            System.out.println("Coming till here : Listen Thread on \n" + upload_port);
            while(true){
                sendthread = new SendThread();
                cl_socket = u_socket.accept();
                sendthread.socket_assign(cl_socket);
                (new Thread(sendthread)).start();
            }
        } catch (IOException ex) {
            Logger.getLogger(MyP2PClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    Socket Mysocket = null;
    DataOutputStream outStrm = null;
    DataInputStream inStrm = null;
    String read_data = null;
    String input = null;
    String filename = null;
    String ip_address = "192.168.1.102";
    Console console = null;
    int port = 7734;
    int upload_port;
    int i = 0;
    int choose;
    String user_input;
    File file = null;
    BufferedReader br = null;
    String content_type = "text/text";
    InetAddress local_ip;
    String version = "P2P-CI/1.0";
    Scanner read = new Scanner(System.in);
    LinkedList MyList = new LinkedList();
    private int user_exit;
    LinkedList temp_ll = new LinkedList();
    int socket_timeout = 100;
    
    String cur_dir = System.getProperty("user.dir");
        
    public void mymain(String[] args) throws IOException {

        //System.out.println("Enter the IP address: ");
        //ip_address = read.nextLine();

        ip_address = "192.168.1.10";
        upload_port = Integer.parseInt(args[0]);
        local_ip = InetAddress.getLocalHost();

        //ListenThread listenthread = new ListenThread();
         MyP2PClass second_thread = new MyP2PClass ();
              
        second_thread.assign_port(upload_port);
        (new Thread (second_thread)).start();

        //listenthread.run(upload_port);

        Mysocket = new Socket(ip_address, port);

        inStrm = new DataInputStream(Mysocket.getInputStream());
        outStrm = new DataOutputStream(Mysocket.getOutputStream());
        
        Mysocket.setSoTimeout(socket_timeout);
        Mysocket.setKeepAlive(true);

        while (true) {
            System.out.println("What do you want to do next?");
            System.out.println("Press 1 for ADDing an RFC");
            System.out.println("Press 2 for LIST of RFCs from server");
            System.out.println("Press 3 for downloading an RFC");
            System.out.println("Press any other ASCII key to exit");

            choose = read.nextInt();

            switch (choose) {
                case 1:{
                    System.out.println("Which RFC you want to add?");
                    user_input = read.next();
                    
                    if(user_input.matches("[0-9]+")){
                        filename = cur_dir + "\\" + user_input + ".txt";
                        System.out.println("Looking for the file, " + filename);
                    }
                    else{
                        System.out.println("Doesn't look like an RFC!!");
                        break;
                    }

                    try {
                        br = new BufferedReader(new FileReader(filename));
                        br.close();
                    } catch (FileNotFoundException fo) {
                        System.out.println("File not found!");
                        break;
                    }
                    if(MyList.contains(user_input))
                        System.out.println("We already have that RFC! Not contacting the server");
                    else
                        add_rfc(user_input);
                }
                break;
                    
                case 2: {
                    System.out.println();
                    list_all();
                }
                break;
                    
                case 3: {
                    System.out.println("\nWhich RFC you want to get?");
                    user_input = read.next();
                    if(MyList.contains(user_input))
                        System.out.println("We already have that RFC! Not contacting the server");
                    else
                        get_an_rfc(user_input);
                }
                break;

                default: {
                    say_bye();
                    user_exit = 1;
                    break;
                }
            }
            if (1 == user_exit) {
                break;
            }
        }

        inStrm.close();
        outStrm.close();
        Mysocket.close();
    }

    private void add_rfc(String cli_input) throws IOException {
        int success = 0;
        String add_rfc = "ADD RFC " + cli_input + " " + version;
        outStrm.writeBytes(add_rfc + "\n");
        outStrm.writeBytes("Host: " + local_ip.getHostAddress() + "\n");
        outStrm.writeBytes("Port: " + upload_port + "\n");
        
        try{
            input = inStrm.readLine();
            System.out.println(input);
        }
        catch(SocketTimeoutException sto) {
            System.out.println("Add RFC failed due to timeout");
            return;
        }
        
        try{
            String input2 = inStrm.readLine();
        }
        catch(SocketTimeoutException sto) {
            //System.out.println("Successfully added the RFC");
        }
        
        if(input.contains(add_rfc)){
            MyList.add(user_input);
        }        
    }

    private void list_all() throws IOException{
        outStrm.writeBytes("LIST ALL " + version + "\n");
        outStrm.writeBytes("Host: " + local_ip.getHostAddress() + "\n");
        outStrm.writeBytes("Port: " + upload_port + "\n");
        
        while(true){
            try{
                input = inStrm.readLine();
                System.out.println(input);
            }catch (SocketTimeoutException so){
                System.out.println("Timedout or end of list ");
                break;
            }
        }
    }

    private void get_an_rfc(String user_input) throws IOException{
        
        int gottherfc = 0;
        int tmp_input;
        int count = 2;
        outStrm.writeBytes("LOOKUP RFC " + user_input + " " + version + "\n");
        outStrm.writeBytes("HOST: " + local_ip.getHostAddress() + "\n");
        outStrm.writeBytes("Port: " + upload_port + "\n");
                
        /* Read the following 3 lines
        1. Status Code and Stuff
        2. Should be a new line string from the server
        First RFC Information */
        while(0 == count){
            try{
                count--;
                input = inStrm.readLine();
                System.out.println(input);
            } catch (SocketTimeoutException snr){
                System.out.println("Server is dumb. Not Responding");
                return;
            }
        }
        
        // Parse the input and get the data from the peer if it is available 
        while(true){
            try{
                input = inStrm.readLine();
                System.out.println(input);
                String delim = "[ ]+";
                String[] data;
                data = input.split(delim);
                if(data[0].equals(user_input))
                {
                    temp_ll.add(data[1]);
                    temp_ll.add(data[2]);
                }
            }catch (SocketTimeoutException so){
                System.out.println("LOOKUP >> Timedout or end of list");
                break;
            }
        }
        System.out.println("Get an RFC>> " + temp_ll);
        
        gottherfc = getfrompeer(user_input);
        
        if(1 == gottherfc)
        {
            System.out.println("Got the RFC " + user_input + ". Do you want to add it to your share list?");
            tmp_input = read.nextInt();
            if(1 == tmp_input){
                add_rfc(user_input);
            }
        }
        
        temp_ll.clear();
    }

    private void say_bye() throws IOException {
        System.out.println("Exiting the client application");
        outStrm.writeBytes("BYE \n");
        input = inStrm.readLine();
        String delim = "[ ]+";
        if (null != input) {
            String[] data = input.split(delim);
            if (data[0].equals("CYA")) {
                System.out.println("Unregistered gracefully");
                return;
            } 
        }
        System.out.println("Unregistered...");
    }

    private int getfrompeer(String user_input) throws IOException {
        int success = 0;
        String ip_addr;
        String temp_port;
        Socket peersocket;
        DataInputStream tmp_inStrm;
        DataOutputStream tmp_outStrm;
        String delim = "[ ]+";
        String[] accept;
        int Content_length;
        
        // System.out.println(count_rfc);
        //get all the ip address of peers
        //contact each peer one by one
        
        System.out.println("Get From Peer>> " + temp_ll);
        
        for(int loop = 0; loop< temp_ll.size(); loop = loop+2){
            ip_addr = (String) temp_ll.get(loop);
            temp_port = (String) temp_ll.get(loop+1);
            
            peersocket = new Socket(ip_addr, Integer.parseInt(temp_port));
            
            tmp_inStrm = new DataInputStream(peersocket.getInputStream());
            tmp_outStrm = new DataOutputStream(peersocket.getOutputStream());
            
            filename = cur_dir + "\\" + user_input + ".txt";
            
            /*Create a file to write to
            Send request
            Wait for the reply and analyze
            */
            
            peersocket.setSoTimeout(socket_timeout);
            tmp_outStrm.writeBytes("GET RFC " + user_input + " " + version + "\n");
            tmp_outStrm.writeBytes("Host: " + local_ip.getHostAddress()+ "\n");
            tmp_outStrm.writeBytes("OS: " + System.getProperty("os.name") + "\n");      
            
            FileOutputStream writefile = new FileOutputStream(filename);
            
            read_data = tmp_inStrm.readLine();
            accept = read_data.split(delim);
            System.out.println(read_data);
            
            if(accept[0].contains(version) && accept[1].contains("200") && accept[2].contains("OK"))
            {
                System.out.println(tmp_inStrm.readLine());
                System.out.println(tmp_inStrm.readLine());
                System.out.println(tmp_inStrm.readLine());
                
                read_data = tmp_inStrm.readLine();
                accept = read_data.split(delim);
                System.out.println(read_data);
                if(accept[0].contains("Content-Length:")){
                    Content_length = Integer.parseInt(accept[1]);
                } else{
                    System.out.println("Bad request from the Peer " + ip_addr + ":" +temp_port);
                }
                System.out.println(tmp_inStrm.readLine()); // Print Content Type
                
                while(true){
                    try{
                        Byte rbyte = tmp_inStrm.readByte();
                        writefile.write(rbyte);
                        writefile.flush();
                    }catch (SocketTimeoutException so){
                        System.out.println("GET >> Timedout or end of list");
                        break;
                    }catch (EOFException eof){
                        success = 1;
                        System.out.println("End of the file reached");
                        break;
                    }
                }
            }
            else
            {
                System.out.println("Failed to get from " + ip_addr + ":" +port);
            }
            writefile.close();
            tmp_inStrm.close();
            tmp_outStrm.close();
            peersocket.close();
        }
        
        return success;
    }

    private void assign_port(int port_up) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        this.upload_port = port_up;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package peer2peerserver;

import java.io.IOException;

/**
 *
 * @author Arjun
 */
public class Peer2PeerServer {

    public static void main(String[] args) throws IOException {
        ServerThread myclass = new ServerThread();
        myclass.server_main(args);
}
}
package peer2peerserver;

import java.io.*;
import java.util.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ServerThread implements Runnable {

    String version = "P2P-CI/1.0";
    Socket clientsocket = null;
    LinkedList l;
    LinkedList l2;
    Object thread_Lock;
    private boolean client_not_active = false;
    String delim = "[ ]+";

    @Override
    public void run()// throws IOException 
    {
        DataOutputStream sos = null;
        DataInputStream sis = null;
        try {
            sos = new DataOutputStream(clientsocket.getOutputStream());
        } catch (IOException ex) {
            Logger.getLogger(ServerThread.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            sis = new DataInputStream(clientsocket.getInputStream());
        } catch (IOException ex) {
            Logger.getLogger(ServerThread.class.getName()).log(Level.SEVERE, null, ex);
        }

        String read;
        try {
            clientsocket.setSoTimeout(5000);
        } catch (SocketException ex) {
            Logger.getLogger(ServerThread.class.getName()).log(Level.SEVERE, null, ex);
        }

        int while_break = 0;
        while (true) {
            try {
                if(client_not_active){
                    read = "BYE";
                } else {
                    read = sis.readLine();   
                }
                String[] data = read.split(delim);

                synchronized (thread_Lock) {
                    switch (data[0]) {
                        case "ADD":
                            int check =1;
                            String rfc_num;
                            String k;
                            String port;
                            String temp;
                            String port_num = String.valueOf(clientsocket.getPort());
                            
                            
                            if (data[1].equals("RFC") && data[3].equals(version)) {
                                //if multiple rfc request for same rfc
                                rfc_num = data[2];

                                temp = sis.readLine();
                                data = temp.split(delim);
                                
                                if (data[0].equals("Host:")) {
                                    //l.add(data[1]);
                                    k = data[1];
                                    temp = sis.readLine();
                                    data = temp.split(delim);
                                    
                                    if (data[0].equals("Port:")) {
                                        port = data[1];
                                    
                                        for(int i=0; i<l.size(); i = i+3){
                                            String rfc_num_temp = (String)l.get(i);
                                            if(rfc_num_temp.equals(rfc_num) && (k.equals(l.get(i+1))) && (port.equals(l.get(i+2)))){
                                                check = 0;
                                                break;
                                            }
                                        }

                                        if(1 == check){ //if(!l.contains(j + " " + k))
                                             l.add(rfc_num);
                                             l.add(k);
                                             l.add(port);
                                             l.add(port_num);
                                             sos.writeBytes(read +"\n");

                                            for(int i=0; i<l2.size(); i = i+2){
                                                String rfc_num_temp = (String)l2.get(i);
                                                if((k.equals(l2.get(i))) && (port.equals(l2.get(i+1)))){
                                                    check = 0;
                                                    break;
                                                }
                                            }
                                            if(1 == check){
                                                l2.add(k);
                                                l2.add(port);
                                                l2.add(port_num);
                                            }
                                        }
                                        else{
                                             sos.writeBytes(version + " 400" + " BAD REQUEST" + "\n");
                                        }
                                    }
                                }
                                else{
                                    temp = sis.readLine();
                                }
                            } else {
                                temp = sis.readLine();
                                temp = sis.readLine();
                                if (!data[1].equals("RFC")) {
                                    sos.writeBytes(version + " 400" + " BAD REQUEST" + "\n");
                                } else {
                                    sos.writeBytes(version + " 505" + " P2P-CI VERSION NOT SUPPORTED" + "\n");
                                }
                            }
                        break;

                        case "LIST":
                            String temp2 = sis.readLine();
                            temp2 = sis.readLine();
                            String list_all="";
                            
                            if (data[1].equals("ALL") && data[2].equals(version)) {
                                if (l.isEmpty()) {
                                    sos.writeBytes(version + " 404 " + "Not Found" + "\n");
                                    break;
                                }
                                sos.writeBytes(version + " " + "200 OK" + "\n\n");

                                int last_index = l.size();
                                for (int i = 0; i < last_index; i = i + 4) {
                                    String rfc_number = (String) l.get(i);
                                    String ip_address = (String) l.get(i + 1);
                                    port = (String) l.get(i+2);
                                    list_all = list_all + rfc_number + " " + ip_address + " " + port + "\n";
                                }
                                sos.writeBytes(list_all);
                            } else {
                                if (!data[1].equals("ALL")) {
                                    sos.writeBytes(version + " 400" + " BAD REQUEST" + "\n");
                                } else {
                                    sos.writeBytes(version + " 505" + " P2P-CI VERSION NOT SUPPORTED" + "\n");
                                }
                            }
                            break;

                        case "LOOKUP": {
                            System.out.println(read);
                            String temp1 = sis.readLine(); // Host info
                            System.out.println(temp1);
                            temp1 = sis.readLine(); // Port info
                            System.out.println(temp1);
                            if (data[1].equals("RFC") && data[3].equals(version)) {

                                if (!l.isEmpty() && l.contains(data[2])) {
                                    sos.writeBytes(version + " " + "200 OK" + "\n\n");
                                } else {
                                    sos.writeBytes(version + " 404 " + "Not Found" + "\n");
                                    break;
                                }

                                int last_index = l.size();
                                for (int i = 0; i < last_index; i = i + 4) {
                                    String rfc_number = ((String) l.get(i));
                                    if (data[2].equals(rfc_number)) {
                                        String ip_address = (String) (l.get(i + 1));
                                        port = (String) l.get(i + 2);
                                        sos.writeBytes(rfc_number + " " + ip_address + " " + port + "\n");
                                    }
                                }
                            } else {
                                if (!data[1].equals("RFC")) {
                                    sos.writeBytes(version + " 400" + " BAD REQUEST" + "\n");
                                } else {
                                    sos.writeBytes(version + " 505" + " P2P-CI VERSION NOT SUPPORTED" + "\n");
                                }
                            }
                        }
                            break;
                            
                        case "BYE": {
                            // Remove the information from the L1 and L2
                            InetAddress ip_addr = clientsocket.getInetAddress();
                            String temp_addr = ip_addr.getHostAddress();
                            String port_num2 = String.valueOf(clientsocket.getPort());
                            
                            if(client_not_active)
                                System.out.println("Client has left abruptly, cleaning up... ");
                            else
                                System.out.println("Client has left gracefully!");
                            
                            for(int i = 1; i < l.size(); i = i + 4){
                                String ip_address = ((String) l.get(i));
                                if (temp_addr.equals(ip_address) && (port_num2.equals(l.get(i+2)))) {
                                    l.remove(i-1);
                                    l.remove(i-1);
                                    l.remove(i-1);
                                    l.remove(i-1);
                                    i = i - 4;
                                }
                            }
                            for(int j = 0; j < l2.size(); j = j + 3){
                                String ip_address = ((String) l2.get(j));
                                if (temp_addr.equals(ip_address) && (port_num2.equals(l2.get(j+2)))) {
                                    l2.remove(j);
                                    l2.remove(j);
                                    l2.remove(j);
                                    j -= 3;
                                }
                            }
                            if(!client_not_active)
                                sos.writeBytes("CYA" + "\n");
                            while_break = 1;
                            
                            System.out.println("Cleaned up the " + ip_addr + ":" + port_num2 + " connection");
                        }
                            break;

                        default:
                            System.out.println("Exit from this loop");
                            break;
                    }
                }
            } catch (SocketTimeoutException ex) {
                Boolean alive = false;
                try {
                    //Check if the client is active or not
                    alive = clientsocket.getKeepAlive();
                } catch (SocketException ex1) {
                    Logger.getLogger(ServerThread.class.getName()).log(Level.SEVERE, null, ex1);
                }
                //System.out.println("getKeepAlive " + alive);
                //Logger.getLogger(ServerThread.class.getName()).log(Level.SEVERE, null, ex);

            } catch (Exception e){
                client_not_active = true;
            }
            if (1 == while_break) {
                break;
            }
        }

        try {
            clientsocket.close();
        } catch (IOException ex) {
            Logger.getLogger(ServerThread.class.getName()).log(Level.SEVERE, null, ex);
            //Logger.getLogger(NewThread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void server_main(String[] args) throws IOException {

        ServerSocket peertopeer;
        peertopeer = new ServerSocket(7734);
        ServerThread newthread;
        Socket[] clntSockArr = new Socket[1024];
        
        Object lock1 = new Object();
        LinkedList link1 = new LinkedList();
        LinkedList link2 = new LinkedList();

        for (int i = 0; i < 1024; i++) { // Can be replaced by while loop without any harm. In the similar way as the client's 2nd thread
            clntSockArr[i] = peertopeer.accept();
            clntSockArr[i].setKeepAlive(true);
            newthread = new ServerThread();
            newthread.assign(clntSockArr[i], lock1, link1, link2);
            (new Thread(newthread)).start();
        }
        peertopeer.close();
    }

    private void assign(Socket cl_socket, Object lock1, LinkedList link1, LinkedList link2) {
        this.clientsocket = cl_socket;
        this.thread_Lock = lock1;
        this.l = link1;
        this.l2 = link2;
    }
}

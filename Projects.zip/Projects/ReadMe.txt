
This folder consists of two projects, namely,
1. proj1 => TCP based, P2P Server Client, RFC Sharing, Centralised Index
	Source Code and ReadMe that has "How to setup and use guidelines for proj1"
2. proj2 => UDP based, Simple FTP, GoBackN, Selective Repeat ARQ
	Source Code 
		for GoBackN
		for Selective Repeat
	Report containing how to use and the observations and analysis of GoBackN and Selective Repeat ARQs

NOTE : Both the projects are implemented in Java and testing in NetBeans IDE.

This is implemented by the following people:

	Name			Unity ID	Student ID
===========================================================
1. Arjun Yadiki			ayadiki		200022299
2. Mithilesh Jaywant Gawande	mgawand		200020941
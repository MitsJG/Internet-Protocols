package selectiverepeat_client;

//package simple_ftp_client;

import java.io.*;
import java.net.*;
import java.util.Arrays;
//import static simple_ftp_client.MyClass.rdt_send;

class MyClass {

    DatagramSocket client_socket;
    String filename;
    int ServerPort;
    String ServerIP;
    byte[] buffer;
    int[] size;
    byte[] recv_data;
    byte[] send_data;
    int buf_cnt = 0;
    byte[][] array;
    int base_seq, max_seq, rcvd_seq;
    long[] time_started;
    int num_packets_sent = 0;
    int cur_sequence_num = 0;
    int RoundTripTime = 0;
    int WindowSize = 0;
    int MSS = 0;
    long timeout = 100;
    int index;
    byte[] temp_arr = new byte[2048];
    int[] ack_rcvd;

    void add_header() throws IOException{

        int checksum = 0;

        array[index] = Arrays.copyOfRange(temp_arr, 0, buf_cnt+9);

        int n = size[index];

        for(int i = n-1; i>=0; i--)
        {
             array[index][i+8] = array[index][i];
        }

        array[index][3] = (byte) (cur_sequence_num & 0xFF);
        array[index][2] = (byte) ((cur_sequence_num >> 8) & 0xFF);
        array[index][1] = (byte) ((cur_sequence_num >> 16) & 0xFF);
        array[index][0] = (byte) ((cur_sequence_num >> 24) & 0xFF);

        array[index][4] = (byte) 0x0;
        array[index][5] = (byte) 0x0;
        array[index][6] = (byte) 0x55;
        array[index][7] = (byte) 0x55;

        n = (n%2 == 0)? n+8: n+9;

        //calculate checksum
        for(int j = 0; j<n-1; j=j+2)
        {
           checksum += ((array[index][j] & 0xFF)<<8) + (array[index][j+1] & 0xFF);
           checksum = ((checksum & 0xFFFF) + (checksum >> 16)&0xFFFF);
        }
        //System.out.println(Integer.toHexString(checksum));
        checksum = ~checksum;
        //System.out.println(Integer.toHexString(checksum));

        array[index][4] = (byte)((checksum >> 8) & 0xFF);
        array[index][5] = (byte)((checksum) & 0xFF);

        //System.out.println(Integer.toHexString(array[index][4]));
        //System.out.println(Integer.toHexString(array[index][5]));
    }

    void rdt_send(String[] args, byte data, int final_call) throws Exception{

        int recv_failed;
        long current_time;

        //System.out.println(buf_cnt);
        //System.out.println(cur_sequence_num);
        buffer[buf_cnt++] = data;
        DatagramPacket receive_ACK = new DatagramPacket(recv_data, 8);

        if((buf_cnt < MSS) && (0 == final_call))
            return;

        //System.out.println(buf_cnt);

        if((cur_sequence_num <= max_seq) && (cur_sequence_num >= base_seq)){
            //Transmit a packet;
            index = cur_sequence_num % WindowSize;
            temp_arr = Arrays.copyOf(buffer, buf_cnt);
            size[index] = buf_cnt;
            //System.out.println("buf_cnt is " + buf_cnt);
            add_header();
            //System.out.println(array[index].length + " " + MSS);
            DatagramPacket send_Data =
                new DatagramPacket(array[index], buf_cnt + 8, Inet4Address.getByName(ServerIP), ServerPort);
            client_socket.send(send_Data);
            //System.out.println("1. size of the sent data is " + (buf_cnt + 8) + " with seq " + cur_sequence_num);
            time_started[index] = System.currentTimeMillis();
            ack_rcvd[index] = 0;
            cur_sequence_num++;
            buf_cnt = 0;
            Arrays.fill(buffer, (byte)0);
            //System.exit(1);
        }

        while(true)
        {
            recv_failed = 0;
            try{
                client_socket.receive(receive_ACK);
            }
            catch(java.net.SocketTimeoutException ste){
                recv_failed = 1;
            }

            if(0 == recv_failed)
            {
                //Parse the ACK packet and update necessary fields;
                //extract info from the ACK

                rcvd_seq = (((recv_data[0] & 0xFF) << 24) |
                            ((recv_data[1] & 0xFF) << 16) |
                            ((recv_data[2] & 0xFF) << 8) |
                            (recv_data[3]& 0xFF));
                //System.out.println("rcvd_seq = " + rcvd_seq);

                if(rcvd_seq == base_seq+1) {
                    base_seq = rcvd_seq;
                    for(int i = base_seq; i<= max_seq; i++){
                        if((cur_sequence_num != 0) && (time_started[i % WindowSize] != 0) &&
                                        (cur_sequence_num > i) && (ack_rcvd[i%WindowSize] == 1))
                        {
                            base_seq += 1;
                        }
                        else{
                            break;
                        }
                    }
                }

                max_seq = base_seq + WindowSize - 1;

                index = (rcvd_seq - 1)%WindowSize;
                ack_rcvd[index] = 1;
            }

            current_time = System.currentTimeMillis();

            //System.out.println(timeout);
            //System.out.println(time_started[base_seq % WindowSize] - current_time);

            for(int i = base_seq; i<= max_seq; i++){
                if((cur_sequence_num != 0) && (time_started[i % WindowSize] != 0) &&
                                    (cur_sequence_num > i) && ((current_time - time_started[i % WindowSize]) > timeout)
                                        && (ack_rcvd[i%WindowSize] == 0))
                {
                    System.out.println("Timeout, sequence number = " + i);
                    index = i % WindowSize;
                    DatagramPacket send_Data =
                    new DatagramPacket(array[index], size[index] + 8, Inet4Address.getByName(ServerIP), ServerPort);
                    //System.out.println("2. size of the sent data is " + (size[index] + 8) + " i= " + i);
                    client_socket.send(send_Data);
                    time_started[index] = System.currentTimeMillis();
                    //ack_rcvd[index] = 0;
                }
            }

            if((0 == final_call) && ((cur_sequence_num - base_seq) < WindowSize))
            {
                //System.out.println("Breaking to send more packet " + cur_sequence_num + " " + base_seq + " " + WindowSize);
                break; //Send more packets
            }

            int itisdone = 1;

            if(final_call == 1)
            {
                for(int i = base_seq; i<= max_seq; i++){
                    if((cur_sequence_num > i) && (ack_rcvd[i%WindowSize] == 0))
                    {
                        //System.out.println("Coming here");
                        itisdone = 0;
                        break;
                    }
                }
                if(1 == itisdone)
                    break;
            }
        }
    }

    void mymain(String[] args) throws Exception{

        byte rd;
        //BufferedReader br = null;
        FileInputStream readfile;
        int final_call = 0;

        ServerIP = args[0];
        ServerPort = Integer.parseInt(args[1]);
        filename = args[2];
        WindowSize = Integer.parseInt(args[3]);
        MSS = Integer.parseInt(args[4]);
        int count =0;
        //readfile = new FileInputStream(System.getProperty("user.dir") + "\\" + filename);

        while(count++ < 155)
        {

        buffer = new byte[(MSS+8) * WindowSize * 2];
        time_started = new long[WindowSize];
        size = new int[WindowSize];
        ack_rcvd = new int[WindowSize];
        //array = new byte[WindowSize][MSS*2*2];
        array = new byte[WindowSize][MSS*2];
        recv_data = new byte[8];
        send_data = new byte[2048];

        max_seq = WindowSize - 1;
        base_seq = 0;
        buf_cnt = 0;
        cur_sequence_num = 0;
        readfile = new FileInputStream(System.getProperty("user.dir") + "\\" + filename);

        //client_socket.setSoTimeout(10);
        //System.out.println(ServerIP);
        //System.out.println(ServerIP.getBytes());
        //System.out.println(InetAddress.getByAddress(ServerIP));
        //System.out.println(Inet4Address.getByName(ServerIP));

        int remBytes = readfile.available();

        long begin_time = System.currentTimeMillis();

        final_call = 0;

        //System.out.println("Start loop " + count + " Window Size is " + WindowSize + " and MSS is " + MSS);

        client_socket.setSoTimeout(10);
           // System.out.println("Here");

        while(0 != remBytes)
        {
            rd = (byte)readfile.read();
            //System.out.println("readthisnow" + rd);
            remBytes = readfile.available();

            if(0 == remBytes)
                final_call = 1;

            rdt_send(args, rd, final_call);
            //if(rd == -1)
              //  break;
        }

        long end_time = System.currentTimeMillis();

        //System.out.println("End Loop Count is " + count + " MSS = " + MSS + " Window Size = " + WindowSize + " Time taken is " + (end_time - begin_time) + " ms");
        readfile.close();
        client_socket.close();
            //Thread.sleep(2000);
        break;
        }
    }
}

public class Simple_ftp_client_sr {
    public static void main(String[] args) throws Exception{

        MyClass instance = new MyClass();
            instance.mymain(args);
    }
}

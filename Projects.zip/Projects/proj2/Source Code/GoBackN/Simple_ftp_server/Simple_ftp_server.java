package simple_ftp_server;

import java.io.*;
import java.net.*;
import java.util.*;

public class Simple_ftp_server {
   
    public static void main(String[] args) throws Exception{

        DatagramSocket serverSocket;
        int current_seq_number = 0;
        //Writer writefile = null;
        FileOutputStream writefile;
        //PrintWriter writefile = new PrintWrite(args[2]);
        String filename = args[1];
        double Prob = Double.parseDouble(args[2]);
        byte[] buf = new byte[2048];
        byte[] for_ack = new byte[8];
        DatagramPacket recv_data = new DatagramPacket(buf, 2048);
        DatagramPacket send_ACK;
        int packet_seq_number = 0;
        int checksum, prev_size, cur_size;
        int thisistheend = 1;
        int skip_process = 0;
        byte[] copy = new byte[2048];
        
        prev_size = 0;
        serverSocket = new DatagramSocket(Integer.parseInt(args[0]));
        
        //writefile = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filename)));
        writefile = new FileOutputStream(filename);
        while(true)
        {
            serverSocket.receive(recv_data);
            skip_process = 0;
            
            //Get seq number
            packet_seq_number = (buf[3] & 0xFF)|
                                ((buf[2] & 0xFF) << 8)|
                                ((buf[1] & 0xFF) << 16)|
                                ((buf[0] & 0xFF) << 24);
            
            if(Math.random()<= Prob) {
                System.out.println("Packet loss, sequence number = " + packet_seq_number);
                skip_process = 1; // Probabilistic Drop
            }

            if(packet_seq_number != current_seq_number) 
                skip_process = 2; //Out of order packet
            
            //Verify Checksum
            cur_size = recv_data.getLength();
            checksum = 0;
            for(int j = 0; j<cur_size-1; j=j+2)
            {
               checksum += ((buf[j] & 0xFF)<<8) + (buf[j+1] & 0xFF);
               checksum = ((checksum & 0xFFFF) + (checksum >> 16)&0xFFFF);
            } 
            
            //System.out.println(checksum);
            
            if(checksum != 0xffff) 
                skip_process = 3; //Corrupt packet, hence drop
            
            //Send an ACK
            SocketAddress Address = recv_data.getSocketAddress();
            
            if(0 == skip_process)
            {
                int temp = ++current_seq_number;
                for_ack[3] = (byte) (temp & 0xFF);
                for_ack[2] = (byte) ((temp >> 8) & 0xFF);
                for_ack[1] = (byte) ((temp >> 16) & 0xFF);
                for_ack[0] = (byte) ((temp >> 24) & 0xFF);

                for_ack[4] = (byte) 0x00;
                for_ack[5] = (byte) 0x00;
                for_ack[6] = (byte) 0xAA;
                for_ack[7] = (byte) 0xAA;

                send_ACK = new DatagramPacket(for_ack, for_ack.length, Address);

                serverSocket.send(send_ACK);

                //System.out.write(for_ack);
                //System.out.println("temp = " + temp);

                if(prev_size != cur_size) 
                    thisistheend = 1 - thisistheend;

                //Save the data
                copy = Arrays.copyOfRange(buf, 8, cur_size);

                //System.out.println(Arrays.toString(copy));
                //System.out.write(copy);
                writefile.write(copy);
                //writefile.write(Arrays.toString(copy));
                //System.out.println("Recv packet with sequence number = " + packet_seq_number);
                writefile.flush();

                prev_size = cur_size;

                if(1 == thisistheend)
                    System.out.println("It looks like the transfer is complete");
            }
            else
            {
                //System.out.println("Skipped due to reason " + skip_process);
                if(skip_process >= 1)
                {
                    send_ACK = new DatagramPacket(for_ack, for_ack.length, Address);
                    serverSocket.send(send_ACK);
                }
            }
        }        
    }    
}

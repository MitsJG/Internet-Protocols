package simple_ftp_client;

import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.Arrays;
import sun.java2d.loops.SurfaceType;
//import static simple_ftp_client.MyClass.rdt_send;

class MyClass {
    
    DatagramSocket client_socket;
    String filename;
    int ServerPort;
    String ServerIP;
    byte[] buffer;
    int[] size;
    byte[] recv_data;
    byte[] send_data;
    int buf_cnt = 0;
    byte[][] array;
    int base_seq, max_seq, rcvd_seq;
    long[] time_started;
    int num_packets_sent = 0;
    int cur_sequence_num = 0;
    int RoundTripTime = 0;
    int WindowSize = 0;
    int MSS = 0;
    long timeout = 20;
    int index;
    byte[] temp_arr = new byte[2048];

    void add_header() throws IOException{
        
        int checksum = 0;
        
        array[index] = Arrays.copyOfRange(temp_arr, 0, buf_cnt+8);
        
        int n = size[index];
        
        for(int i = n-1; i>=0; i--)
        {
             array[index][i+8] = array[index][i];
        }

        array[index][3] = (byte) (cur_sequence_num & 0xFF);
        array[index][2] = (byte) ((cur_sequence_num >> 8) & 0xFF);
        array[index][1] = (byte) ((cur_sequence_num >> 16) & 0xFF);
        array[index][0] = (byte) ((cur_sequence_num >> 24) & 0xFF);
        
        array[index][4] = (byte) 0x0;
        array[index][5] = (byte) 0x0;        
        array[index][6] = (byte) 0x55;
        array[index][7] = (byte) 0x55;
        
        n = (n%2 == 0)? n+8: n+9;
        
        //calculate checksum
        for(int j = 0; j<n-1; j=j+2)
        {
           checksum += ((array[index][j] & 0xFF)<<8) + (array[index][j+1] & 0xFF);
           checksum = ((checksum & 0xFFFF) + (checksum >> 16)&0xFFFF);
        }
        //System.out.println(Integer.toHexString(checksum));
        checksum = ~checksum;
        //System.out.println(Integer.toHexString(checksum));
        
        array[index][4] = (byte)((checksum >> 8) & 0xFF);
        array[index][5] = (byte)((checksum) & 0xFF);
        
        //System.out.println(Integer.toHexString(array[index][4]));
        //System.out.println(Integer.toHexString(array[index][5]));
    }
    
    void rdt_send(String[] args, byte data, int final_call) throws Exception{
            
        int recv_failed = 0;
        long current_time;
        
        //System.out.println(buf_cnt);
        //System.out.println(cur_sequence_num);
        buffer[buf_cnt++] = data;
        DatagramPacket receive_ACK = new DatagramPacket(recv_data, 8);
        
        if((buf_cnt < MSS) && (0 == final_call))
            return;
        
        if((cur_sequence_num <= max_seq) && (cur_sequence_num >= base_seq)){
            //Transmit a packet;
            index = cur_sequence_num % WindowSize;
            temp_arr = Arrays.copyOf(buffer, buf_cnt);
            size[index] = buf_cnt;
            //System.out.println("buf_cnt is " + buf_cnt);
            add_header();
            //System.out.println(array[index].length + " " + MSS);
            DatagramPacket send_Data = 
                new DatagramPacket(array[index], buf_cnt + 8, Inet4Address.getByName(ServerIP), ServerPort);
            client_socket.send(send_Data);
            //System.out.println("1. size of the sent data is " + (buf_cnt + 8));
            time_started[index] = System.currentTimeMillis();
            cur_sequence_num++; 
            buf_cnt = 0;
            //System.exit(1);
        }       
        
        while(true)
        {   
            recv_failed = 0;
            try{
                client_socket.receive(receive_ACK);
            }
            catch(java.net.SocketTimeoutException ste){
                recv_failed = 1;
            }

            if(0 == recv_failed)
            {
                rcvd_seq = (((recv_data[0] & 0xFF) << 24) | 
                            ((recv_data[1] & 0xFF) << 16) | 
                            ((recv_data[2] & 0xFF) << 8) | 
                            (recv_data[3]& 0xFF)); //Will this work?
                //System.out.println("rcvd_seq = " + rcvd_seq);
                
                max_seq = max_seq + (rcvd_seq - base_seq);
                base_seq = rcvd_seq; //extract info from the ACK
                //Parse the ACK packet and update necessary fields;
                
                if((final_call == 1) && (cur_sequence_num == rcvd_seq))
                    break; // Successful
            }
            
            current_time = System.currentTimeMillis();
            
            //System.out.println(timeout);
            //System.out.println(time_started[base_seq % WindowSize] - current_time);
            if((cur_sequence_num != 0) && (time_started[base_seq % WindowSize] != 0) && 
                                (cur_sequence_num > base_seq) && ((current_time - time_started[base_seq % WindowSize]) > timeout))
            {
                System.out.println("Timeout, sequence number = " + base_seq);
                //System.out.println("Number of packets unacked = " + (cur_sequence_num - base_seq));
                for(int i = base_seq; i<= max_seq; i++){
                    if(cur_sequence_num > i){
                        index = i % WindowSize;
                        DatagramPacket send_Data = 
                        new DatagramPacket(array[index], size[index] + 8, Inet4Address.getByName(ServerIP), ServerPort);
                        client_socket.send(send_Data);
                        //System.out.println("2. size of the sent data is " + (size[index] + 8));
                        time_started[index] = System.currentTimeMillis();
                        //break;
                    }
                }
            }
            
            if((0 == final_call) && ((cur_sequence_num - base_seq) < WindowSize))
            {
                break; //Send more packets
            }
        }
    }
    
    void mymain(String[] args) throws Exception{
        
        byte rd;
        //BufferedReader br = null;
        FileInputStream readfile;
        int final_call = 0;
        
        client_socket = new DatagramSocket();
        ServerIP = args[0];
        ServerPort = Integer.parseInt(args[1]);
        filename = args[2];
        WindowSize = Integer.parseInt(args[3]);
        MSS = Integer.parseInt(args[4]);
        readfile = new FileInputStream("C:\\Users\\Arjun\\Desktop\\Projects\\IP_Prjct2\\Files\\"+filename);
        
        buffer = new byte[(MSS+8) * WindowSize * 2];
        time_started = new long[WindowSize];
        size = new int[WindowSize];
        //array = new byte[WindowSize][MSS*2*2];
        array = new byte[WindowSize][MSS*2];
        recv_data = new byte[8];
        send_data = new byte[2048];
        max_seq = WindowSize - 1;
        base_seq = 0;
        
        client_socket.setSoTimeout(10);
        //System.out.println(ServerIP);
        //System.out.println(ServerIP.getBytes());
        //System.out.println(InetAddress.getByAddress(ServerIP));
        System.out.println(Inet4Address.getByName(ServerIP));
        
        int remBytes = readfile.available();
        
        long begin_time = System.currentTimeMillis();
        
        while(0 != remBytes)
        {
            rd = (byte)readfile.read();
            //System.out.println("readthisnow" + rd);
            remBytes = readfile.available();
            
            if(0 == remBytes)
                final_call = 1;
            
            rdt_send(args, rd, final_call);
            //if(rd == -1)
              //  break;
        }
        
        long end_time = System.currentTimeMillis();
        
        System.out.println("Time taken for the transfer is " + (end_time - begin_time) + "ms");
        readfile.close();
        client_socket.close();
    }
}

public class Simple_ftp_client {
    public static void main(String[] args) throws Exception{
        
        MyClass instance = new MyClass();
            instance.mymain(args);
    }    
}
